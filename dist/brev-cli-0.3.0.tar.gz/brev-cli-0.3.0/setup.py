# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['brev_cli', 'brev_cli.static']

package_data = \
{'': ['*']}

install_requires = \
['click>=7.1.2,<8.0.0',
 'cotter @ git+https://github.com/theFong/python-sdk.git@master',
 'pyfiglet>=0.8.post1,<0.9',
 'python-jose>=3.2.0,<4.0.0',
 'pyyaml>=5.3.1,<6.0.0',
 'requests>=2.24.0,<3.0.0',
 'yaspin>=1.3.0,<2.0.0']

entry_points = \
{'console_scripts': ['brev = brev_cli.main:cli']}

setup_kwargs = {
    'name': 'brev-cli',
    'version': '0.3.0',
    'description': 'The CLI for Brev.Dev!',
    'long_description': None,
    'author': 'nader',
    'author_email': 'nader+cli@brev.dev',
    'maintainer': None,
    'maintainer_email': None,
    'url': 'https://brev.dev',
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'entry_points': entry_points,
    'python_requires': '>=3.7,<4.0',
}


setup(**setup_kwargs)
